
/*弹出层*/
/*
    参数解释：
    title   标题
    url     请求的url
    id      需要操作的数据id
    w       弹出层宽度（缺省调默认值）
    h       弹出层高度（缺省调默认值）
*/
function x_admin_show(title,url,w,h){
   window.location.href=url;
	
}

function x_top_show(title,url,w,h){
   window.location.href=url;
	
}




