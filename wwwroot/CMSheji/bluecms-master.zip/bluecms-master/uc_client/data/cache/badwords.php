<?php
$_CACHE['badwords'] = array (
);

?>