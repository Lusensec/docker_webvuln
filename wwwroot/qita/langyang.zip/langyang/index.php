<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>狼羊游戏</title>
	<script>
		function lanjie(){
			alert('房间创建之后，请等待小伙伴的加入，勿退出！')
		}
	</script>
</head>
<body>
<center>
	<h1>创建或进入游戏房间</h1>
	<form action="login.php" method="POST">
	<table>
		<tr>
			<td>
				<input type="text" name="home_num" placeholder="请输入房间号">
			</td>
		</tr>
		<tr>
			<td>
				<input type="password" name="home_pass" placeholder="请输入房间密码">
			</td>
		</tr>
		<tr>
			<td>
				<input type="text" name="home_username" placeholder="请输入用户名">			
			</td>
		</tr>
		<tr>
			<td>
				<input type="submit" name="home_create" value="创建房间" onclick="lanjie()">
				<input type="submit" name="home_into" value="进入房间">				
			</td>
		</tr>
	</table>
	</form>
</center>
</body>
</html>