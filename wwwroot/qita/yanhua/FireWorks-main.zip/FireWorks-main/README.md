# FireWorks
基于Html+Canvas写的一个2023年3D跨年烟花代码、可以自己修改字以及音乐
![image](https://user-images.githubusercontent.com/100667496/210128516-65d52244-e7f0-4d58-a070-e9bb490be78e.png)
![image](https://user-images.githubusercontent.com/100667496/210128526-c415578c-12d4-4d7f-9b34-ded8e809c83f.png)
![image](https://user-images.githubusercontent.com/100667496/210128529-700dcf80-5d3a-4327-ba4d-6f71ce06e441.png)



