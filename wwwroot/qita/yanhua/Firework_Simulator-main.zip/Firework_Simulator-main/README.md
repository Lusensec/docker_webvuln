# 烟花模拟器

注意：此源码是基于 [Firework Simulator v2](https://codepen.io/MillerTime/pen/XgpNwb) 的二次修改

我仅作翻译处理以及其他优化

Demo 1：https://nianbroken.github.io/Firework_Simulator/

Demo 2：https://fireworks.nianbroken.top/

------

展示图

![静态图](https://cdn.jsdelivr.net/gh/NianBroken/Firework_Simulator/Image_Preview.png)

------

若有翻译错译或其他问题，请在`Issues`提交。
